
function validateForm() {
  let myForm = document.forms["myForm"];
  var patt = new RegExp("[a-zA-Z].{4,}");
  var emailPatt = new RegExp("[a-zA-Z].{4,}[@][a-zA-Z].{2,}[.][a-zA-Z].{2,}");
  var passPatt = new RegExp("(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}");
  var mobPatt = new RegExp("[0-9].{10}");

  if (!patt.test(myForm["uname"].value)) {
    alert("Name must be filled out!");
    return false;
  }
  if (!emailPatt.test(myForm["email"].value)) {
    alert("Please fill email in a proper format!");
    return false;
  }
  if (!patt.test(myForm["city"].value)) {
    alert("City name must be filled out");
    return false;
  }
  if (!passPatt.test(myForm["psw"].value)) {
    alert("Password must contain one uppercase, one lowercase, one digit");
    return false;
  }
  if (!mobPatt.test(myForm["mobile"].value)) {
    alert("Mobile No must have 10 digits");
    return false;
  }
}

function validateLogin(){
	let myForm = document.forms["myForm"];
  	var patt = new RegExp("[a-zA-Z].{4,}");
  	var passPatt = new RegExp("(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}");
  	if (!patt.test(myForm["uname"].value)) {

    	alert("Name must be filled out!");
    	return false;
  	}
  	if (!passPatt.test(myForm["psw"].value)) {
    	alert("Password must contain one uppercase, one lowercase, one digit");
    	return false;
  	}
}